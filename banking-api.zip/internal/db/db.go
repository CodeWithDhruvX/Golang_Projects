package db

import (
    "log"
    "os"

    "gorm.io/driver/mysql"
    "gorm.io/gorm"
    "banking-api/internal/models"
)

func Connect() *gorm.DB {
    dsn := os.Getenv("DB_DSN")
    if dsn == "" {
        log.Fatal("DB_DSN is empty! Ensure .env is loaded.")
    }
    
    db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
    if err != nil {
        log.Fatalf("[error] failed to initialize database, got error %v", err)
    }
    
    // Auto-migrate models (comment out if using manual schema.sql)
    err = db.AutoMigrate(&models.Customer{}, &models.Branch{}, &models.Account{}, &models.Transaction{}, &models.Loan{}, &models.LoanPayment{}, &models.Beneficiary{})
    if err != nil {
        log.Fatalf("AutoMigrate failed: %v", err)
    }
    log.Println("Database connected and migrated successfully!")
    
    return db
}
