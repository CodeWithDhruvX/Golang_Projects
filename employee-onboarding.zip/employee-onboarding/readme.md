Get-Content ../.env

it will read the env content


https://www.perplexity.ai/search/employee-on-boarding-system-dy-Waio.o1.Tp.yclcAYRpuug