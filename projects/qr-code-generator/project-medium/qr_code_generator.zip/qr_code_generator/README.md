# qr_code_generator

Complete Go implementation of a QR code generator demonstrating:
- Factory Method pattern
- Thread-safe map cache
- PostgreSQL integration with GORM
- Standard, Custom and Batch QR generators
- QR scanner (using tuotoo/qrcode)


https://chatgpt.com/c/68c916d1-a1fc-8323-8b24-3da67e29af4b