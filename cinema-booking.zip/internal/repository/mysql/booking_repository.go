package mysql

import (
    "database/sql"
    "encoding/json"

    "cinema-booking/internal/domain"
)

type BookingRepository struct {
    db *sql.DB
}

func NewBookingRepository(db *sql.DB) *BookingRepository {
    return &BookingRepository{db: db}
}

func (r *BookingRepository) Create(booking *domain.Booking) error {
    seatIDsJSON, _ := json.Marshal(booking.SeatIDs)
    query := `INSERT INTO bookings (show_id, seat_ids, user_id, user_name, booked_at) VALUES (?, ?, ?, ?, ?)`
    res, err := r.db.Exec(query, booking.ShowID, seatIDsJSON, booking.UserID, booking.UserName, booking.BookedAt)
    if err != nil {
        return err
    }
    id, _ := res.LastInsertId()
    booking.ID = int(id)
    return nil
}

func (r *BookingRepository) ListByShowID(showID int) ([]*domain.Booking, error) {
    query := `SELECT id, show_id, seat_ids, user_name, booked_at FROM bookings WHERE show_id = ?`
    rows, err := r.db.Query(query, showID)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    var bookings []*domain.Booking
    for rows.Next() {
        var b domain.Booking
        var seatIDsJSON []byte
        if err := rows.Scan(&b.ID, &b.ShowID, &seatIDsJSON, &b.UserName, &b.BookedAt); err != nil {
            return nil, err
        }
        json.Unmarshal(seatIDsJSON, &b.SeatIDs)
        bookings = append(bookings, &b)
    }
    return bookings, nil
}

func (r *BookingRepository) GetByID(id int) (*domain.Booking, error) {
    query := `SELECT id, show_id, seat_ids, user_id, user_name, booked_at FROM bookings WHERE id = ?`
    row := r.db.QueryRow(query, id)
    var b domain.Booking
    var seatIDsJSON []byte
    err := row.Scan(&b.ID, &b.ShowID, &seatIDsJSON, &b.UserID, &b.UserName, &b.BookedAt)
    if err != nil {
        return nil, err
    }
    json.Unmarshal(seatIDsJSON, &b.SeatIDs)
    return &b, nil
}

func (r *BookingRepository) Delete(id int) error {
    query := `DELETE FROM bookings WHERE id = ?`
    _, err := r.db.Exec(query, id)
    return err
}

func (r *BookingRepository) ListByUserID(userID int) ([]*domain.Booking, error) {
    query := `SELECT id, show_id, seat_ids, user_name, booked_at FROM bookings WHERE user_id = ?`
    rows, err := r.db.Query(query, userID)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    var bookings []*domain.Booking
    for rows.Next() {
        var b domain.Booking
        var seatIDsJSON []byte
        if err := rows.Scan(&b.ID, &b.ShowID, &seatIDsJSON, &b.UserName, &b.BookedAt); err != nil {
            return nil, err
        }
        json.Unmarshal(seatIDsJSON, &b.SeatIDs)
        bookings = append(bookings, &b)
    }
    return bookings, nil
}
