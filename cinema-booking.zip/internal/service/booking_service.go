package service

import (
    "encoding/json"
    "time"

    "cinema-booking/internal/domain"
    "cinema-booking/internal/repository/mysql"
)

type BookingService struct {
    seatSvc    *SeatService
    bookingRepo *mysql.BookingRepository
    seatRepo   *mysql.SeatRepository
}

func NewBookingService(seatSvc *SeatService, bookingRepo *mysql.BookingRepository, seatRepo *mysql.SeatRepository) *BookingService {
    return &BookingService{seatSvc: seatSvc, bookingRepo: bookingRepo, seatRepo: seatRepo}
}

func (s *BookingService) BookTickets(req *domain.CreateBookingRequest) (*domain.Booking, error) {
    seats, err := s.seatSvc.GetAvailableSeats(req.ShowID)
    if err != nil {
        return nil, err
    }

    for _, seatID := range req.SeatIDs {
        available := false
        for _, seat := range seats {
            if seat.ID == seatID && !seat.IsBooked {
                available = true
                break
            }
        }
        if !available {
            return nil, domain.ErrSeatNotAvailable
        }
    }

    booking := &domain.Booking{
        ShowID:  req.ShowID,
        SeatIDs: req.SeatIDs,
        UserID:  req.UserID,
        UserName: "User",  // Fetch from user service in prod
        BookedAt: time.Now(),
    }

    tx, err := s.bookingRepo.db.Begin()
    if err != nil {
        return nil, err
    }
    defer tx.Rollback()

    if err := s.bookingRepo.Create(booking); err != nil {
        return nil, err
    }

    for _, seatID := range req.SeatIDs {
        seat := &domain.Seat{ID: seatID, IsBooked: true}
        if err := s.seatRepo.Update(seat); err != nil {
            return nil, err
        }
    }

    if err := tx.Commit(); err != nil {
        return nil, err
    }

    return booking, nil
}

func (s *BookingService) CancelBooking(bookingID int, userID int) error {
    booking, err := s.bookingRepo.GetByID(bookingID)
    if err != nil {
        return domain.ErrBookingNotFound
    }
    if booking.UserID != userID {
        return domain.ErrNotOwner
    }
    for _, seatID := range booking.SeatIDs {
        seat := &domain.Seat{ID: seatID, IsBooked: false}
        if err := s.seatRepo.Update(seat); err != nil {
            return err
        }
    }
    return s.bookingRepo.Delete(bookingID)
}

func (s *BookingService) ListBookingsByUser(userID int) ([]*domain.Booking, error) {
    return s.bookingRepo.ListByUserID(userID)
}
